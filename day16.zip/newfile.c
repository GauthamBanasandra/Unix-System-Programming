testlude <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>

void copy();
int main()
{
#if 0
	copy();
#endif
#if 0
	int fd;
	fd = open("1_redirection.c", O_RDONLY);
	if(fd  == -1)
	{
		perror("open"); exit(1);
	}
	close(0);
	dup(fd);
	close(fd);
	copy();
#endif
	int fd;
	int fdout;
	fd = open("1_redirection.c", O_RDONLY);
	if(fd  == -1)
	{
		perror("open"); exit(1);
	}

	fdout = open("newfile.c", O_CREAT | O_WRONLY,  0644);
	if(fdout  == -1)
	{
		perror("open"); exit(1);
	}

	close(0);
	dup(fd);
	close(fd);

	close(1);
	dup(fdout);
	close(fdout);

	copy();
}

void copy()
{
	char ch;
	while( (ch = getchar()) != EOF)
	{
		putchar(ch);
	}
}













