if ls y
then
	echo "success"
else
	echo "failure"
fi
