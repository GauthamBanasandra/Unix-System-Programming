#include <stdio.h>
void bar1()
{
	printf("bar1 called\n");
}
void bar2()
{
	printf("bar2 called\n");

} 
