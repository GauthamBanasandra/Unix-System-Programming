#include <stdio.h>
void foo1()
{
	printf("foo1 called\n");
}
void foo2()
{
	printf("foo2 called\n");

} 
