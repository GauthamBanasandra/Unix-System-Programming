#include <stdio.h>
void foo1();
void foo2();
void bar1();
void bar2();

int main()
{
	foo1();
	bar2();
}


