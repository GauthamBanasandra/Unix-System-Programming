#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <signal.h>

int main()
{
	sigset_t x;
	sigemptyset(&x);
	sigaddset(&x, 2);
	printf("2 ? %d\n", sigismember(&x, 2));
	printf("3 ? %d\n", sigismember(&x, 3));
	

}
