#include <stdio.h>
#include <stdlib.h>

int main()
{
	printf("begin\n");
	system("ps");
	printf("end\n");
}
